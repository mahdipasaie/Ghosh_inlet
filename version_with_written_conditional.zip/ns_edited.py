import fenics as fe
import numpy as np
from scipy.ndimage import binary_dilation, binary_erosion
# Define the custom tanh function
def custom_tanh(x):
    return 2 / (1 + fe.exp(-2 * x)) - 1

def smooth_heaviside(phi, threshold, epsilon):
    return 0.5 * (1 - custom_tanh((phi - threshold) / epsilon))

def transform_phi(phi, epsilon=0.1):
    threshold = 0  # This is the midpoint in the range of phi
    return smooth_heaviside(phi, threshold, epsilon)

def modify_u_with_conditional(solution_vector, phi, epsilon=1e-8):
    u, p = solution_vector.split(deepcopy=True)
    # phi_function_space = spaces_pf[0]
    # u_function_space = space_ns[0]
    # Transform phi using smooth Heaviside
    u_modified = fe.project(transform_phi(phi, epsilon) * u, u.function_space())

    u.assign(u_modified)
    fe.assign(solution_vector, [u, p])
    

    
    return solution_vector





def mark_and_bc(mesh, solution_vector_pf, spaces_pf, comm):

    def value_coor_dof(solution_vector_pf, spaces_pf, comm):
        """Return value of the solution at the degrees of freedom and corresponding coordinates."""
        # v_phi = spaces_pf[0]
        # (phi, u) = solution_vector_pf.split(deepcopy=True)
        v_phi = spaces_pf
        phi = solution_vector_pf
        coordinates_of_all = v_phi.tabulate_dof_coordinates()
        phi_value_on_dof = phi.vector().get_local()

        # grad_Phi = project(sqrt(fe.dot(grad(phi), grad(phi))), v_phi)
        # phi_value_on_dof = grad_Phi.vector().get_local()

        all_Val_dof = comm.gather(phi_value_on_dof, root=0)
        all_point = comm.gather(coordinates_of_all, root=0)

        # Broadcast the data to all processors
        all_point = comm.bcast(all_point, root=0)
        all_Val_dof = comm.bcast(all_Val_dof, root=0)

        # Combine the data from all processors
        all_Val_dof_1 = [val for sublist in all_Val_dof for val in sublist]
        all_point_1 = [point for sublist in all_point for point in sublist]

        point = np.array(all_point_1)
        Val_dof = np.array(all_Val_dof_1)

        return Val_dof, point

    def coordinates_of_marking(solution_vector_pf, spaces_pf, comm):
        """Get the small mesh and return coordinates of the interface."""
        dof_value, dof_Coor = value_coor_dof(solution_vector_pf, spaces_pf, comm)
        index_list = np.argwhere(dof_value > 0.99)
        if index_list.size == 0:
            return np.array([])  # Return an empty array if no indices are found
        index_list = np.concatenate(index_list)
        list_coordinate_points = dof_Coor[index_list]
        return list_coordinate_points

    def mark_mesh(mesh, solution_vector_pf, spaces_pf, comm):
        list_coordinate_points = coordinates_of_marking(solution_vector_pf, spaces_pf, comm) 
        mf = fe.MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
        len_mf = len(mf)
        cell_id_list = []
        tree = mesh.bounding_box_tree()
        for Cr in list_coordinate_points:
            cell_id = tree.compute_first_entity_collision(fe.Point(Cr))
            if cell_id != 4294967295 and 0 <= cell_id < len_mf:
                cell_id_list.append(cell_id)
        cell_id_list = np.unique(np.array(cell_id_list, dtype=int))
        mf.array()[cell_id_list] = 1

        cell_array = mf.array()
        cell_array = binary_dilation(cell_array, iterations=4)
        cell_array = binary_erosion(cell_array, iterations=4)
        mf.set_values(cell_array.astype(np.int32))

        return mf

    def bc_markers(solid_markers, mesh):
        # Create a MeshFunction to mark the facets (boundaries) of the solid region
        facet_markers = fe.MeshFunction("size_t", mesh, mesh.topology().dim() - 1, 0)
        for facet in fe.facets(mesh):
            cells = [cell for cell in fe.cells(facet)]
            if any(solid_markers[cell.index()] == 1 for cell in cells):
                facet_markers[facet] = 1
        return facet_markers

    # Mark the mesh
    mf = mark_mesh(mesh, solution_vector_pf, spaces_pf, comm)

    # Create boundary condition markers
    facet_markers = bc_markers(mf, mesh)

    return facet_markers



def apply_bc_based_on_phi(mesh, W, phi):
    # Create a MeshFunction for facet markers
    facet_markers = fe.MeshFunction("size_t", mesh, mesh.topology().dim() - 1, 0)

    # First loop: Identify cells where the average value of phi is 1
    cells_with_phi_1 = []
    for cell in fe.cells(mesh):
        if phi(cell.midpoint()) == 1.0:
            cells_with_phi_1.append(cell)
    # Second loop: Mark the facets of identified cells
    for cell in cells_with_phi_1:
        for facet in fe.facets(cell):
            facet_markers[facet] = 1
    # Apply the Dirichlet boundary condition to the marked facets
    bc = fe.DirichletBC(W.sub(0), fe.Constant((0.0, 0.0)), facet_markers, 1)

    return bc

def apply_zero_velocity_bc(mesh, W, threshold):
    # Define the solid region
    solid_subdomain = Solid(threshold)
    
    # Mark the solid region
    solid_markers = fe.MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
    solid_subdomain.mark(solid_markers, 1)
    
    # Create a MeshFunction to mark the facets (boundaries) of the solid region
    facet_markers = fe.MeshFunction("size_t", mesh, mesh.topology().dim() - 1, 0)
    for facet in fe.facets(mesh):
        cells = [cell for cell in fe.cells(facet)]
        if any(solid_markers[cell.index()] == 1 for cell in cells):
            facet_markers[facet] = 1
    
    # Apply the Dirichlet boundary condition
    bc_solid = fe.DirichletBC(W.sub(0), fe.Constant((0.0, 0.0)), facet_markers, 1)
    return bc_solid

# Define the custom tanh function
def custom_tanh(x):
    return (fe.exp(x) - fe.exp(-x)) / (fe.exp(x) + fe.exp(-x))

def smooth_heaviside(phi, threshold, epsilon):
    return 0.5 * (1 - custom_tanh((phi - threshold) / epsilon))

# Define a transformation function to map phi from [-1, 1] to [1, 0]
def transform_phi(phi, epsilon= 0.1):
    threshold = 0  # This is the midpoint in the range of phi
    return smooth_heaviside(phi, threshold, epsilon)

Bc = None

class InflowProfile(fe.UserExpression):
    def __init__(self, vel_x, max_y, **kwargs):
        self.vel_x = vel_x
        self.max_y = max_y
        super().__init__(**kwargs)

    def eval(self, values, x):
        if x[1] <= self.max_y:
            values[0] = 0.0
        else:
            values[0] = self.vel_x
        values[1] = 0.0

    def value_shape(self):
        return (2,)

class InitialConditions_ns(fe.UserExpression):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)  

    def eval(self, values, x):
        values[0] = 0.001  # Initial x-component of velocity
        values[1] = 0.0  # Initial y-component of velocity
        values[2] = 0.0  # Initial pressure

    def value_shape(self):
        return (3,)

class Solid(fe.SubDomain):
    def __init__(self, threshold):
        super().__init__()
        self.threshold = threshold

    def inside(self, x, on_boundary):
        return x[1] < self.threshold
    
def define_variables_ns(mesh):

    # Define finite elements for velocity, pressure, and temperature
    P1 = fe.VectorElement("Lagrange", mesh.ufl_cell(), 2)  # Velocity
    P2 = fe.FiniteElement("Lagrange", mesh.ufl_cell(), 1)  # Pressure 

    viscosity_func_space = fe.FunctionSpace(mesh, P2)
    phi_prev_interpolated_on_ns_mesh = fe.Function(viscosity_func_space)
    u_prev_interpolated_on_ns_mesh = fe.Function(viscosity_func_space)

    # Define mixed elements
    element = fe.MixedElement([P1, P2])

    # Create a function space
    function_space_ns = fe.FunctionSpace(mesh, element)

    # Define test functions
    test_1, test_2 = fe.TestFunctions(function_space_ns)

    # Define current and previous solutions
    solution_vector_ns = fe.Function(function_space_ns)  # Current solution
    solution_vector_ns_0 = fe.Function(function_space_ns)  # Previous solution

    # Split functions to access individual components
    u_answer, p_answer = fe.split(solution_vector_ns)  # Current solution
    u_prev, p_prev = fe.split(solution_vector_ns_0)  # Previous solution


       # Collapse function spaces to individual subspaces
    num_subs = function_space_ns.num_sub_spaces()
    spaces_ns, maps = [], []
    for i in range(num_subs):
        space_i, map_i = function_space_ns.sub(i).collapse(collapsed_dofs=True)
        spaces_ns.append(space_i)
        maps.append(map_i)

    return {
        'u_answer': u_answer, 'u_prev': u_prev,
        'p_answer': p_answer, 'p_prev': p_prev,
        'solution_vector_ns': solution_vector_ns, 'solution_vector_ns_0': solution_vector_ns_0,
        'test_1': test_1, 'test_2': test_2,
        'spaces_ns': spaces_ns, 'function_space_ns': function_space_ns,
        "phi_prev_interpolated_on_ns_mesh": phi_prev_interpolated_on_ns_mesh,
        "u_prev_interpolated_on_ns_mesh": u_prev_interpolated_on_ns_mesh, "viscosity_func_space": viscosity_func_space
    }

def epsilon(u):  

    return 0.5 * (fe.grad(u) + fe.grad(u).T)

def sigma(u, p):

    return 2  * epsilon(u) - p * fe.Identity(len(u))

def Traction(T, n_v, gamma):

    return gamma *(fe.grad(T) - fe.dot(n_v, fe.grad(T)) * n_v)

def F1(variables_dict, physical_parameters_dict):
    dt = physical_parameters_dict["dt"]
    test_2 = variables_dict['test_2']
    u_answer = variables_dict['u_answer']
    f1 = fe.inner(fe.div(u_answer)/dt, test_2)  * fe.dx
    return f1

def F2(variables_dict, physical_parameters_dict):
    # thermo-physical properties:
    W0_scale = physical_parameters_dict['W0_scale']
    tau_0_scale = physical_parameters_dict['tau_0_scale']
    mu_fluid = physical_parameters_dict['mu_fluid'](tau_0_scale, W0_scale)
    gravity = physical_parameters_dict['gravity'](tau_0_scale, W0_scale)
    viscosity_liquid = physical_parameters_dict['viscosity_liquid'](mu_fluid)
    rho_liquid = physical_parameters_dict["rho_liquid"]
    rho_solid = physical_parameters_dict["rho_solid"]
    k_eq = physical_parameters_dict['k_eq']
    opk = physical_parameters_dict['opk'](k_eq)
    omk = physical_parameters_dict['omk'](k_eq)
    # dt = physical_parameters_dict['dt']
    dt = physical_parameters_dict["dt"]
    u_answer = variables_dict['u_answer']
    u_prev = variables_dict['u_prev']
    p_answer = variables_dict['p_answer']
    test_1 = variables_dict['test_1']
    phi = variables_dict['phi_prev_interpolated_on_ns_mesh']
    U = variables_dict['u_prev_interpolated_on_ns_mesh']
    ######################## Coeff of boyancy ########################
    viscosity_solid = viscosity_liquid * 1E6
    dy_mu_article = ( viscosity_solid/ rho_liquid )* (1 + phi)/2 + ( viscosity_liquid / rho_liquid) * (1 - phi)/2 # depends on range of Phi

    dy_mu = viscosity_liquid/rho_liquid # changed 
    beta = 1E6  
    threshold = 1  
    epsilon0 = 0.1  # width of the transition region
    penalization_term = beta * smooth_heaviside(phi, threshold, epsilon0) * u_answer

    # F2 = (
    #     fe.inner((u_answer - u_prev) / dt, test_1) 
    #     + fe.inner(fe.dot(u_answer, fe.grad(u_answer)), test_1) 
    #     + dy_mu * fe.inner(fe.grad(u_answer), fe.grad(test_1) ) 
    #     + (1/rho_liquid) * fe.inner(fe.grad(p_answer), test_1) 
    #     + fe.inner(penalization_term, test_1)  
    # ) * fe.dx
    # Define the weak form with conditional expression


    F2_conditional = (
    fe.inner((u_answer - u_prev) / dt, test_1)
    + fe.inner(fe.dot(u_answer, fe.grad(u_answer)), test_1)
    + dy_mu * fe.inner(fe.grad(u_answer), fe.grad(test_1))
    + (1 / rho_liquid) * fe.inner(fe.grad(p_answer), test_1)
    ) *transform_phi(phi) * fe.dx
    
    # * fe.conditional(phi < 1, fe.Constant(1.0), fe.Constant(0.0)) * fe.dx

    # F2 = (
    #     fe.inner((u_answer - u_prev) / dt, test_1) 
    #     + fe.inner(fe.dot(u_answer, fe.grad(u_answer)), test_1) 
    #     + dy_mu * fe.inner(sigma(u_answer, p_answer), epsilon(test_1)) 
    #     + fe.inner(penalization_term, test_1)  # Penalization term subtracted # maybe use both together
    #     # - fe.inner( Coeff2_Bou_NS , test_1[1] ) #bouyancy
    # ) * fe.dx
    return F2_conditional 

def define_boundary_condition_ns(variables_dict, physical_parameters_dict, mesh) :
    global Bc
    Nx = physical_parameters_dict['Nx']
    Ny = physical_parameters_dict['Ny']
    Domain = physical_parameters_dict['Domain'](Nx, Ny)
    vel_x = physical_parameters_dict['vel_x']
    W = variables_dict['function_space_ns']
    phi = variables_dict['phi_prev_interpolated_on_ns_mesh']
    max_y = physical_parameters_dict["max_y"]
    min_y = physical_parameters_dict["min_y"]
    comm = physical_parameters_dict["comm"] 
    spaces_pf = variables_dict["viscosity_func_space"]
    it = physical_parameters_dict["it"]
    ther = max_y - ( max_y - min_y ) / 2
    (X0, Y0), (X1, Y1) = Domain
    # inflow_profile = InflowProfile(vel_x=vel_x, max_y=max_y, degree=2)
    inflow_profile = fe.Expression(
        ('(x[1] <= ther) ? 0.0 : vel_x', 'vel_x'),
        vel_x=vel_x, ther= ther, degree=2
    ) # anyway vel_x is applied

    inflow = f'near(x[0], {X0})'
    outflow = f'near(x[0], {X1})'
    walls = f'near(x[1], {Y0}) || near(x[1], {Y1})'
    # Define boundary conditions
    bcu_inflow = fe.DirichletBC(W.sub(0), inflow_profile, inflow)
    bcu_walls = fe.DirichletBC(W.sub(0), fe.Constant((0, 0)), walls)
    bcp_outflow = fe.DirichletBC(W.sub(1), fe.Constant(0), outflow)

    Bc = [bcu_inflow, bcu_walls, bcp_outflow]

    return  Bc

def define_problem_ns(L, variables_dict, physical_parameters_dict):

    global Bc  


    solution_vector_ns = variables_dict['solution_vector_ns']

    abs_tol_ns = physical_parameters_dict["abs_tol_ns"]
    rel_tol_ns = physical_parameters_dict["rel_tol_ns"]
    linear_solver_ns = physical_parameters_dict['linear_solver_ns']
    nonlinear_solver_ns = physical_parameters_dict['nonlinear_solver_ns']
    preconditioner_ns = physical_parameters_dict['preconditioner_ns']
    maximum_iterations_ns = physical_parameters_dict['maximum_iterations_ns']

    J = fe.derivative(L, solution_vector_ns)
    problem_ns = fe.NonlinearVariationalProblem(L, solution_vector_ns, Bc, J)
    solver_ns = fe.NonlinearVariationalSolver(problem_ns)

    solver_parameters = {
        'nonlinear_solver': nonlinear_solver_ns,
        'snes_solver': {
            'linear_solver': linear_solver_ns,
            'report': False,
            "preconditioner": preconditioner_ns,
            'error_on_nonconvergence': False,
            'absolute_tolerance': abs_tol_ns,
            'relative_tolerance': rel_tol_ns,
            'maximum_iterations': maximum_iterations_ns,
        }
    }


    solver_ns.parameters.update(solver_parameters)

    return solver_ns

def update_solver_on_new_mesh_ns(mesh, physical_parameters_dict, old_solution_vector_ns= None, old_solution_vector_0_ns=None, 
                                old_solution_vector_0_pf=None, variables_dict= None):
    
    global Bc
    
    # define new solver after mesh refinement: 
    if old_solution_vector_ns is not None and old_solution_vector_0_ns is not None and old_solution_vector_0_pf is not None:

        variables_dict = define_variables_ns(mesh)

        solution_vector_ns = variables_dict['solution_vector_ns']
        solution_vector_ns_0 = variables_dict['solution_vector_ns_0']
        phi_prev_interpolated_on_ns_mesh = variables_dict['phi_prev_interpolated_on_ns_mesh']
        u_prev_interpolated_on_ns_mesh = variables_dict['u_prev_interpolated_on_ns_mesh']
        function_space_ns = variables_dict['function_space_ns']
        space_ns = variables_dict["spaces_ns"]

        # interpolate initial condition  after mesh refinement:
        fe.LagrangeInterpolator.interpolate(solution_vector_ns, old_solution_vector_ns)
        fe.LagrangeInterpolator.interpolate(solution_vector_ns_0, old_solution_vector_0_ns)

        # define the new boundary condition after mesh refinement:
        Bc = define_boundary_condition_ns(variables_dict, physical_parameters_dict, mesh)

        # gettting the old solution vector for the phase field and concentration field on ns mesh:
        phi_prev, u_prev = old_solution_vector_0_pf.split(deepcopy=True)
        fe.LagrangeInterpolator.interpolate(phi_prev_interpolated_on_ns_mesh , phi_prev)
        fe.LagrangeInterpolator.interpolate(u_prev_interpolated_on_ns_mesh , u_prev)


        # define the new forms after mesh refinement:
        f1_form = F1(variables_dict, physical_parameters_dict)
        f2_form = F2(variables_dict, physical_parameters_dict)

        # Define solver: 
        L= f1_form + f2_form
        solver_ns= define_problem_ns(L, variables_dict, physical_parameters_dict)

        return { 
            'solver_ns': solver_ns, 'solution_vector_ns': solution_vector_ns, 'solution_vector_ns_0': solution_vector_ns_0,
            "phi_prev_interpolated_on_ns_mesh": phi_prev_interpolated_on_ns_mesh,
            "u_prev_interpolated_on_ns_mesh": u_prev_interpolated_on_ns_mesh, "space_ns": space_ns,
            "Bc": Bc, "variables_dict": variables_dict, "function_space_ns": function_space_ns
        }

    # define the initial condition for the first time step:
    if old_solution_vector_ns is None and old_solution_vector_0_ns is  None and old_solution_vector_0_pf is  None and variables_dict is None: 

        variables_dict = define_variables_ns(mesh)
        solution_vector_ns = variables_dict['solution_vector_ns']
        solution_vector_ns_0 = variables_dict['solution_vector_ns_0']
        phi_prev_interpolated_on_ns_mesh = variables_dict['phi_prev_interpolated_on_ns_mesh']
        u_prev_interpolated_on_ns_mesh = variables_dict['u_prev_interpolated_on_ns_mesh']
        space_ns = variables_dict['spaces_ns']
        function_space_ns = variables_dict['function_space_ns']

        # interpolate initial condition  after mesh refinement:
        initial_conditions = InitialConditions_ns()
        solution_vector_ns_0.interpolate(initial_conditions)
        solution_vector_ns.interpolate(initial_conditions)

        # define the new boundary condition after mesh refinement:
        Bc = define_boundary_condition_ns(variables_dict, physical_parameters_dict, mesh)


        # define the new forms after mesh refinement:
        f1_form = F1(variables_dict, physical_parameters_dict)
        f2_form = F2(variables_dict, physical_parameters_dict)

        # Define solver: 
        L= f1_form + f2_form
        solver_ns= define_problem_ns(L, variables_dict, physical_parameters_dict)

        return { 
            'solver_ns': solver_ns, 'solution_vector_ns': solution_vector_ns, 'solution_vector_ns_0': solution_vector_ns_0,
            "space_ns": space_ns, "Bc": Bc, "variables_dict": variables_dict,
            "function_space_ns": function_space_ns, "phi_prev_interpolated_on_ns_mesh": phi_prev_interpolated_on_ns_mesh,
        }


    #updating: 
    if variables_dict is not None:


        phi_prev_interpolated_on_ns_mesh = variables_dict['phi_prev_interpolated_on_ns_mesh']
        u_prev_interpolated_on_ns_mesh = variables_dict['u_prev_interpolated_on_ns_mesh']
        space_ns = variables_dict['spaces_ns']
        function_space_ns = variables_dict['function_space_ns']

        # gettting the old solution vector for the phase field and concentration field on ns mesh:
        phi_prev, u_prev = old_solution_vector_0_pf.split(deepcopy=True)
        fe.LagrangeInterpolator.interpolate(phi_prev_interpolated_on_ns_mesh , phi_prev)
        fe.LagrangeInterpolator.interpolate(u_prev_interpolated_on_ns_mesh , u_prev)

        # define boundary condition:
        Bc = define_boundary_condition_ns(variables_dict, physical_parameters_dict, mesh)


        # define the new forms after mesh refinement:
        f1_form = F1(variables_dict, physical_parameters_dict)
        f2_form = F2(variables_dict, physical_parameters_dict)

        # Define solver: 
        L= f1_form + f2_form
        solver_ns= define_problem_ns(L, variables_dict, physical_parameters_dict)

        return { 
            "variables_dict": variables_dict, "solver_ns": solver_ns,
            "phi_prev_interpolated_on_ns_mesh": phi_prev_interpolated_on_ns_mesh, "u_prev_interpolated_on_ns_mesh": u_prev_interpolated_on_ns_mesh,
            "space_ns": space_ns, "Bc": Bc,
            "function_space_ns": function_space_ns
        }












